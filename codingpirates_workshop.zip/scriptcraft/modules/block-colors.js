var colors = {
  white: 0,
  orange: 1,
  magenta: 2,
  lightblue: 3,
  yellow: 4,
  lime: 5,
  pink: 6,
  gray: 7,
  lightgray: 8,
  cyan: 9,
  purple: 10,
  blue: 11,
  brown: 12,
  green: 13,
  red: 14,
  black: 15
};
module.exports = colors;
