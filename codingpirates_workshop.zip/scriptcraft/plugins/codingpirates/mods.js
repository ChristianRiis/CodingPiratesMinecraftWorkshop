/*
  Fil til at skrive Javascript-kode til Minecraft workshop
  CodingPirates Odense lørdag d. 5. marts 2016
*/
var Drone = require('drone');


// Dette er en kommentar



function hejVerden() {


}
exports.testjs = hejVerden;


function minDroneTest() {
  console.log('Jeg tester min drone ...');



}
